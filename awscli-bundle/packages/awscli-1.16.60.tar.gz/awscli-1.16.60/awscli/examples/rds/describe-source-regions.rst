**To describe source regions**

This example describes all of the source regions::

    aws rds describe-source-regions

Output::

{
    "SourceRegions": [
        {
            "RegionName": "ap-northeast-1",
            "Endpoint": "https://rds.ap-northeast-1.amazonaws.com",
            "Status": "available"
        },

<...output omitted...>

}
